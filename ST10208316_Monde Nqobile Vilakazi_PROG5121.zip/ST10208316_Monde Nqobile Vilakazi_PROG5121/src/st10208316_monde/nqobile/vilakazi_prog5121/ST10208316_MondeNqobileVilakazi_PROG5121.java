/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package st10208316_monde.nqobile.vilakazi_prog5121;

import java.util.*;
import javax.swing.*;

public class ST10208316_MondeNqobileVilakazi_PROG5121 {
    
    

    public static void main(String[] args) {
        JFrame mm1 = new JFrame();
        Scanner mm2 = new Scanner(System.in);
        
        System.out.print("Enter your first name >> ");
        String firstName = mm2.nextLine();
        
        System.out.print("Enter your last name >> ");
        String lastName = mm2.nextLine();
        
        System.out.print("Create a username >> ");
        String username = mm2.nextLine();
        
        System.out.print("Create a password >> ");
        String password = mm2.nextLine();
        
        System.out.print("Enter your username >> ");
        String userName = mm2.nextLine();
        
        System.out.print("Enter your password >> ");
        String passWord = mm2.nextLine();
        
        System.out.println("----Login----");
        
        System.out.println(Login.checkUsername(username));
        System.out.println(Login.checkPasswordComplexity(password));
        System.out.println(Login.registerUser(true, true));
        System.out.println(Login.loginUser(username, userName, password, passWord));
        System.out.println(Login.returnLoginStatus(true, true));
        System.out.println("Welcome back "+firstName +  " " + lastName + ", it is great to see you back");
        
        //Task 2
        //display message 
        JOptionPane.showMessageDialog(mm1,"Welcome to Kanban");
        
        //initializing a variable
        int a=0;
        
        //loop to always come back to the menu
        while(a != 3){
            
        //display input message for choosing option    
            int promptOption = Integer.parseInt(JOptionPane.showInputDialog(mm1,"Choose option below: " + "\n"
                    + "1.Add and display tasks\n"
                    + "2.Show Report\n"
                    + "3.Exit"));
            
        //condition to display whatever the user punched in the option prompt    
            if(promptOption ==1){
        
         //Object
        JFrame mm3 = new JFrame();
        //Variable
        int e = 0;
        
        //Declaring array variables and initializing 
        int taskNumber = Integer.parseInt(JOptionPane.showInputDialog(mm3,"Number of tasks"));
        String [] taskName = new String[taskNumber];
        String [] taskDescription = new String[taskNumber];
        String [] developerName = new String[taskNumber];
        int [] minutes = new int[taskNumber];
        int [] status = new int[taskNumber];
        
        //Variables
        boolean isYes;
        boolean isNo;
        boolean isCancel;
        
        String c = "1";
        String b = "2";
        String d = "3";
                
        int cc = Integer.parseInt(c);
        int bb = Integer.parseInt(b);
        int dd = Integer.parseInt(d);
        
        //loop to iterate for number of task needed to be completed
        for(int i=0; i < taskNumber; i++)
        {
            //Declaring variables, initializing and prompting user 
            String taskNames = JOptionPane.showInputDialog(mm1,"Name of task","Task Name",JOptionPane.INFORMATION_MESSAGE);
            taskName[i] = taskNames;
            
            String taskDescriptions = JOptionPane.showInputDialog(mm1,"Enter task description","Description",JOptionPane.INFORMATION_MESSAGE);
            taskDescription[i] = taskDescriptions;
            
            String developerNames = JOptionPane.showInputDialog(mm1,"Name of developer","Developer Name",JOptionPane.INFORMATION_MESSAGE);
            developerName[i] = developerNames;
            
            int startMinutes = Integer.parseInt(JOptionPane.showInputDialog(mm1,"Duration of the task","Duration",JOptionPane.INFORMATION_MESSAGE));
            minutes[i] = startMinutes;
            
            int statuses = Integer.parseInt(JOptionPane.showInputDialog(mm1,"Are you completed with your task ??" + "\nAnswer: " + "\n1.For To Do" + "\n2.For Done" + "\n3.Doing"));
            //if statement to determine status of task
            if(statuses == cc){
                isYes = (statuses == JOptionPane.YES_OPTION);
                JOptionPane.showMessageDialog(mm3,"STATUS: TO DO");
            }
            
            if(statuses == bb){
                isNo = (statuses == JOptionPane.NO_OPTION);
                JOptionPane.showMessageDialog(mm3, "STATUS: DONE");
            }
            
            if(statuses == dd){
                isCancel = (statuses == JOptionPane.CANCEL_OPTION);
                JOptionPane.showMessageDialog(mm3,"STATUS: DOING");
            }
            status[i] = statuses;
           
        }
        
        //A while loop to keep the programming running until prompted to end
        while(e != 6)
        {
            //Declaring varialbe and prompting user to choose 
            int option = Integer.parseInt(JOptionPane.showInputDialog(mm1,"Choose display option below" + "\n"
                    + "1.Display the developer, task names, task description and status" + "\n"
                    + "2.Display the developer, duration of the class with the longest duration" + "\n"
                    + "3.Search for a task and display the tasks name, developer and task status" + "\n"
                    + "4.Delete a task" + "\n"
                    + "5.Display a FULL REPORT of all task details" + "\n"
                    + "6.Exit"));
            
            //if statements to produce the display of the developer's name, task name, task description and status
            if(option == 1)
            {
                //for loop to iterate the number of tasks needed to be completed
                for(int x =0; x < taskNumber;++x)
                {
                    JOptionPane.showMessageDialog(mm1,"DETAILS: " + "\n" + "Developer Name: " + developerName[x] + "\nTask Name: " + taskName[x] + "\nTask Description: " + taskDescription[x] + "\nStatus: " + "Done");
                }
            }
            //if statements to produce the display of the developer's name and duration of the class with the longest duration
            if(option == 2)
            {
                //for loop to iterate the number of tasks needed to be completed    
                for(int x=0;x < taskNumber;++x)
                {
                    JOptionPane.showMessageDialog(mm1,"DETAILS: " + "\n" + "Developer Name: " + developerName[x] + "\nDuration: " + minutes[x] + "minutes");
                }
            }
            
            //if statement to produce the search for a task and displaying the tasks name, developer name and task status
            if(option == 3)
            {
                //Declared variable
                String search = JOptionPane.showInputDialog(mm1,"Search for a task");
                
                //for loop to iterate the number of tasks needed to be completed
                for(int x =0; x < taskNumber; ++x){
                    
                    if(search.equals(taskName[x])){
                        JOptionPane.showMessageDialog(mm1,"REPORT " + (x + 1) + "\nTask Name: " + taskName[x] + "\nDeveloper Name: " + developerName[x] + "\nStatus: " + status[x]);
                    }
                }
            }
            
            //if statement to produce a delete task
            if(option == 4)
            {
                //Declared variable
                String deleteTask = JOptionPane.showInputDialog(mm1,"Which task you want to delete ??");
                
                //for loop to iterate the number of tasks needed to be completed
                for(int x=0; x < taskNumber; ++x)
                {
                    if(deleteTask.equals(taskName[x]))
                    {
                         ArrayList<String> name = new ArrayList<>();
                         name.remove(taskName[x]);
                         JOptionPane.showMessageDialog(mm1, taskName[x] + " has been deleted");
                    }
                }
                
            }
            
            //if statement to produce the display of task name, task description, developer's name, task duration and task status
            if(option == 5)
            {
                //for loop to iterate the number of tasks needed to be completed
                for(int x=0; x < taskNumber; ++x)
                {
                    JOptionPane.showMessageDialog(mm1,"FULL REPORT " + "\nTask No." + (x + 1) + "\nTask Name: " + taskName[x] + "\nTask Description: " + taskDescription[x] + "\n"
                            + "Developer Name: " + developerName[x] + "\nDuration: " + minutes[x] + "\nStatus: " + status[x]);
                }
            }
            //if statemnent for user to exit the application
            if(option == 6)
            {
                e = 6;
                System.exit(0);
            }
        }
                
           
        }
        //if statement to display message    
        else if(promptOption == 2){
                
                JOptionPane.showMessageDialog(mm1,"Feature Coming Soon");
                
        }
        //if statement to end application
        else if(promptOption == 3)
        {
            a = 3;
            System.exit(0);
        }
               
            
        
        }
        
    }
    
}
    

